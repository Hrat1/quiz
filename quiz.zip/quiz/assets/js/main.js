
$( document ).ready(function() {

	$('#checkAnswers').hide();
	$('#answersResponse').hide();

	$('#startQuiz').on('click', function () {

		$('#quizsList').html("");
		getQuizList();
		$('#startQuiz').hide();
		$('#checkAnswers').show();
	});

	$('#checkAnswers').on('click', checkAnswers);
});


function getQuizList() {

	let randomQuizes = [];
	let quizsCount = quizData.length;
	let output = "";
	$('#answersResponse').hide();


	// get random quiz numbers for array
	while (randomQuizes.length < 50) {

	  	let randomNum = Math.floor(Math.random() * quizsCount); 
	  	if (randomQuizes.indexOf(randomNum) === -1) { 
	    	randomQuizes.push(randomNum); 
	  	}
	}

	// Getting quiz and create html with foreach  
	for (var i = 0; i < randomQuizes.length; i++) {

	  	var index = randomQuizes[i];

	  	if (index >= 0 && index < quizData.length) { 
	    
	    	let quiz = quizData[index];
	    	let answers = Object.keys(quiz['answers']).map((key) => {
			  return {
			    0: Number(key),
			    1: quiz['answers'][key]
			  };
			});

	    	for (var a = answers.length - 1; a > 0; a--) {

			  let j = Math.floor(Math.random() * (a + 1)); // Generate random index
			  let temp = answers[a];
			  answers[a] = answers[j];
			  answers[j] = temp;
			}

	    	//let answers = Object.keys(quiz['answers']).map((key) => [Number(key), quiz['answers'][key]]);
	    	let answersOutput = "";

	    	for (var k = 0; k < answers.length; k++) {

		  		//let randomValue = getRandomValue(answers);
	    		let correctAnswer = null;

	    		if (answers[k][1] == quiz['correct']) {
	    			correctAnswer = 1;
	    		}

		  		answersOutput += `<div class="form-check rounded-2 pt-2 pb-2">
					<input class="form-check-input answer" type="radio" name="question` + i + `" id="question`+i+`_answer`+ k +`" value="` + answers[k][1] + `" data-correct="`+ correctAnswer+`">
					<label class="form-check-label" for="question`+i+`_answer` +k +`">`+ answers[k][1] +`</label>
				</div>`;
			}

	    	output += `<div class="mb-3 border rounded-2 p-3 px-4"> 
	    					<label for="question` + i +`" class="form-label">` + quiz['question'] +`</label>` 
	    					+ answersOutput + 
    					`</div>`;

	  	}
	}
	
	$("html, body").animate({ scrollTop: 0 }, "slow");
	$('#quizsList').html(output);

}


function checkAnswers() {

	let checkedAnswers = $('input[type="radio"].answer:checked');
	let correctAnswers = $('input[type="radio"].answer').filter('[data-correct="1"]');
	let wrongAnswers = 0;
	let correctAnswersPercentage;

	checkedAnswers.each(function() {

		if ($(this).data('correct') == null) {

			wrongAnswers += 1;
			$(this).parent().addClass('bg-danger');
		}
	});

	correctAnswers.each(function() {
	  	$(this).parent().addClass('bg-success');
	});

	correctAnswersPercentage = 100 - (wrongAnswers * 2);


	$('#wrongAnswersCount').text(wrongAnswers);
	$('#percent').text(correctAnswersPercentage);
	$('#startQuiz').show();
	$('#checkAnswers').hide();
	$('#answersResponse').show();
}





