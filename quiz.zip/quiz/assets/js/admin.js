// global variables 
let ADMIN_SESSION = localStorage.getItem("logged_admin");
let QUIZ_ID = localStorage.getItem("quiz_id");
let LOCATION = window.location.href;
// admin username and password 
const USER = "admin";
const PASS = "admin";


$( document ).ready(function() {

    // if location is in the login page and admin is logged in then redirect to main page 
    if (LOCATION.indexOf("login.html") !== -1 && ADMIN_SESSION !== null) {

        window.location.replace('./index.html');
    }
    // if is logged out redirect to login page
    if ((LOCATION.indexOf("index.html") !== -1 ||
        LOCATION.indexOf("create_or_update.html") !== -1 ||
        LOCATION.indexOf("quiz.html") !== -1) && ADMIN_SESSION === null) 
    {

        window.location.replace('./login.html');
    }

    $('#login').on('click', login);

    $('#logout').on('click', function () {
        localStorage.removeItem("logged_admin");
        window.location.replace('./login.html');
    });
    // redirect to create quiz page 
    $('#create_quiz_btn').on('click', function () {
        window.location.replace('./quiz.html');
    });
    $('#create_question_btn').on('click', function () {

        if (true) {}
        window.location.replace('./create_or_update.html');
    });

    //window.location.replace('./login.html');
    
    


});


function login () 
{
    let username = $('#username').val();
    let password = $('#password').val();


    if (username == USER && password == PASS) {

        localStorage.setItem("logged_admin", "ok");
        window.location.replace('./index.html');
    }else{
        alert('Մուտքանունը կամ Գաղտնաբառը սխալ է:');
    }
}

